import { devicechkService } from './devicechk.service';

import { NgModule } from '@angular/core';
 
@NgModule({
    declarations: [
    ],
    providers: [
		devicechkService,],
    imports: [
    ],
    exports: [ 
      ]
})
export class pgutilModule {}