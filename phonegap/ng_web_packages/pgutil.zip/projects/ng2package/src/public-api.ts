/*
 * Public API Surface
 */
export * from './ng2package.module';
//export all components here
//export * from './svygmaps/svygmaps';
export * from './devicechk.service';