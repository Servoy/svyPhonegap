/*
 * A service for working with the device's/phone's keyboard - when running the client wrapped inside a PhoneGap app.
 */

function showKeyboard() {}
function hideKeyboard() {}
function isVisibleKeyboard(tp) {}
function setResizeModeKeyboard(tp) {}
function setKeyboardStyleKeyboard(tp) {}
function disableScrollKeyboard(tp) {}