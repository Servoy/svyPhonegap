/*
 * A service gives access to device property information - when running the client wrapped inside a PhoneGap app.
 */

function getDeviceInfoProperty(propertyName) {
}

function getDeviceInfo() {
}
