/*
 * A service that can be used for opening URLs in the browser (internal or external) - when running the client wrapped inside a PhoneGap app.
 */

/**
 * Open a link in the device's default browser.
 * @param {String} url address of web page
 */
function openExternalLink() {
}

function openHrefTag(url) {
}
