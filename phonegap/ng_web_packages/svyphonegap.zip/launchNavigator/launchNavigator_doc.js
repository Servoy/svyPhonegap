/*
 * A service for working with the device's (map) navigation app - when running the client wrapped inside a PhoneGap app.
 */

function launchNavigator(address) {}
