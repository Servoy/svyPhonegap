/*
 * A service that can be used to interact with the device's printing API - when running the client wrapped inside a PhoneGap app.
 */

function print(content, options, callback) {}
function printPDF(content, callback) {}
function pick(options, callback) {}
