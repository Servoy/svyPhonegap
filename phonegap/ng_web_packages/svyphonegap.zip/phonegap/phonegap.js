angular.module('svyphonegapPhonegap', ['servoy']).factory("svyphonegapPhonegap", function($services, $window) {
    var scope = $services.getServiceScope('svyphonegapPhonegap');
    return {
        init: function(onReady) {

            App = {
            	
            	cloneAsObject: function(obj) {
        		    if (obj === null || !(obj instanceof Object)) {
        		        return obj;
        		    }
        		    var temp = (obj instanceof Array) ? [] : {};
        		    // ReSharper disable once MissingHasOwnPropertyInForeach
        		    for (var key in obj) {
        		        temp[key] = this.cloneAsObject(obj[key]);
        		    }
        		    return temp;
        		},
            	
                initialize: function() {
                    this.bindEvents();
                },

                bindEvents: function() {
                    document.addEventListener('deviceready', this.onDeviceReady, false);

                },
                onDeviceReady: function() {
                	console.log('device ready!')
                    document.addEventListener("pause", onPause, false);
                    document.addEventListener("resume", onResume, false);

                    $window.executeInlineScript(onReady.formname,onReady.script, []);
                    
                    //get build info
                    cordova.getAppVersion.getVersionNumber(function (d) {		                		            
    		            Servoy.buildInfo.versionNumber = d;
    		        });
                    
                    cordova.getAppVersion.getVersionCode(function (d) {		                		            
    		            Servoy.buildInfo.versionCode = d;
    		        });
                    
                    cordova.getAppVersion.getPackageName(function (d) {		                		            
    		            Servoy.buildInfo.packageName = d;
    		        });
                    
                    cordova.getAppVersion.getAppName(function (d) {		                		            
    		            Servoy.buildInfo.appName = d;
    		        });                    

                    document.addEventListener("backbutton", function(e) {
                        e.preventDefault();
                        onBack();
                    }, false);

                    function onBack() {                      	
                        console.log('back');
                        // Handle the hardware back button event

                        try {
                            if (Servoy.onBackMethod) {
                                $window.executeInlineScript(Servoy.onBackMethod.formname, Servoy.onBackMethod.script, []);
                            }
                        } catch (e) {
                            console.log(e)
                        }
                    }

                    //runs when the app is on background
                    function onPause() {
                        console.log('pause');
                        // Handle the pause event
                        try {
                            if (Servoy.onPauseMethod) {
                            	$window.executeInlineScript(Servoy.onPauseMethod.formname, Servoy.onPauseMethod.script, []);                                
                            }
                        } catch (e) {
                            console.log(e)
                        }
                    }

                    //runs when the app resumes
                    function onResume() {
                        console.log('resume');
                        // Handle the resume event
                        try {
                            if (Servoy.onResumeMethod) {
                            	$window.executeInlineScript(Servoy.onResumeMethod.formname, Servoy.onResumeMethod.script, []);                                
                            }
                        } catch (e) {
                            console.log(e)
                        }
                    }
                }
            };

            Servoy = {
            	watchID:null,
                initwebview: null,
                bridgeInit: null,
                onPauseMethod: null,
                onResumeMethod: null,
                onBackMethod: null,
				buildInfo:{
					versionCode:null,
					appName:null,
					packageName:null,
					versionNumber:null
				},
                setPauseMethod: function(cb) {
                	console.log(cb)
                    //set call back for servoy client
                    Servoy.onPauseMethod = cb;
                },
                setResumeMethod: function(cb) {
                    //set call back for servoy client
                    Servoy.onResumeMethod = cb;
                },
                setBackMethod: function(cb) {
                    //set call back for servoy client
                    Servoy.onBackMethod = cb;
                }
            }

            App.initialize();
        },
        setOnResumeMethod: function(callback) {
            try {
                Servoy.setResumeMethod(callback);
            } catch (e) {
                console.error('Error : ' + e.message)
            }
        },
        setOnPauseMethod: function(callback) {
            try {
                Servoy.setPauseMethod(callback);
            } catch (e) {
                console.error('Error :' + e.message)
            }
        },
        setOnBackMethod: function(callback) {
            try {
                Servoy.setBackMethod(callback);
            } catch (e) {
                console.error('Error :' + e.message)
            }
        },
        exit: function(callback) {
            try {
                if (navigator.app) {
                    navigator.app.exitApp();
                } else if (navigator.device) {
                    navigator.device.exitApp();
                } else {
                    window.close();
                }
            } catch (e) {
                console.error('Error : ' + e.message)
            }
        },
        quitServoySolution: function(){
        	sessionStorage.clear();
        	location.reload();
        },
        executeScript: function(script, scriptArgs) {
            var mArgs = scriptArgs;
            if (!Array.isArray(scriptArgs)) {
                mArgs = [scriptArgs]
            }
            var f = eval("(" + script + ")");
            return f.apply(this, mArgs);
        },
		getBuildInfo: function(){
			return Servoy.buildInfo;						  
		}
    }
}).run(function($rootScope, $services) {})