/*
 * A service for working with device orientation - when running the client wrapped inside a PhoneGap app.
 */

function lock(orientationType) {}
function unlock() {}
function getOrientationTypes() {}
function setOrientationChangeCallback(callbackMethod) {}
